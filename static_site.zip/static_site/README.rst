Static Site Folder
===================

In this folder the Frontend developer will create the markup for the static version of the site.